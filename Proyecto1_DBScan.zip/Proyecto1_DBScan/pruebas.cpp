#include <omp.h>
#include <iostream>
#include <string>
#include <fstream>
#include <cmath>
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>

using namespace std; 

int main() {
    omp_set_num_threads(12);
    long long int size = 4000;
    long long int suma = 0;

    float** points = new float*[size];

    for(long long int i = 0; i < size; i++) {
        points[i] = new float[3]{1.0, 1.0, 1.0}; 
        // index 0: position x
        // index 1: position y 
        // index 2: 0 for noise point, 1 for core point
    }
    
    long long int k;
    long long int tam = size / 4;
    double start_time = omp_get_wtime();
    #pragma omp sections
    {
        #pragma omp section
        {
            for(k=0; k < tam; k++){
                if(points[k][2] == 1.0){
                    suma++;
                }
            }
        }
        
        #pragma omp section
        {
            for(k = tam; k < tam * 2; k++){
                if(points[k][2] == 1.0){
                    suma++;
                }
            }
        }

         #pragma omp section
        {
            for(k = tam * 2; k < tam * 3; k++){
                if(points[k][2] == 1.0){
                    suma++;
                }
            }
        }
        
        #pragma omp section
        {
            for(k = tam * 3; k < size; k++){
                if(points[k][2] == 1.0){
                    suma++;
                }
            }
        }

    }
        
    double end_time = omp_get_wtime();

    cout << "La suma resulta ser: " << suma << "\n"; 
    cout << "Tiempo: " << end_time - start_time << "\n"; 

    return 0;
}