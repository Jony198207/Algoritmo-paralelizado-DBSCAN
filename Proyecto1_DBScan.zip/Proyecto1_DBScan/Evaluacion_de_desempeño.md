
<div style="text-align: center;">
    <h1>Experimento de paralelización del algoritmo DBSCAN para la 
    detección de ruido u 
    outliers con OpenMP
</h1>
    <h2> Instituto Tecnológico Autónomo de México </h2>
    <h2> Cómputo Paralelo y en la Nube </h2> 
</div>

<h3> Profesor </h3>

<h5> Dr. José Octavio Gutiérrez García </h5>

<h3> Desarrollado por </h3>

<h5> Jonathan de Jesús Gutiérrez Diaz - 191001 </h5>

<h2> Introducción </h2>

<p style="text-align: justify;">
El presente proyecto consiste en el desarrollo y comparación entre la eficiencia de la implementación serial y la implementación paralela del algoritmo de detección de datos <em>outliers</em> conocido como DBSCAN. Se trata de un algoritmo que clusteriza un determinado volúmen de datos mediante una distancia epsilón y un mínimo de puntos dentro del rango de dicha longitud, lo que ocasiona que dichos puntos puedan ser considerados como puntos core de primer grado; caso contrario, se consideran puntos <em>outlier</em> a menos de que, una vez definidos los puntos core de primer grado, los puntos ruido sean epsilón-alcanzables desde un nodo core, esto los categorizaría como punto core de segundo grado.
</p>

<p style="text-align: justify;">
La distancia entre puntos para verificar si un punto es epsilon-alcanzable de otro se puede calcular de diversas formas, entre ellas:
</p>

<ul>
    <li>Distancia euclidiana</li>
    <li>Distancia de Minkowski</li>
    <li>Distancia de Manhattan</li>
    <li>Distancia de Chebychev</li>
    <li>Distancia de Canberra</li>
</ul>

<p style="text-align: justify;">
En nuestro caso, al tratarse de datos con valores entre 0 y 1 con coordenadas (X,Y) nos es favorable y suficiente utilizar la distancia euclidiana para la definición de la distancia en el algoritmo. Recordemos que esta fórmula se calcula de la forma:
</p>

$$
\text{Distancia Euclidiana} = \sqrt{(x_2 - x_1)^2 + (y_2 - y_1)^2}
$$

<h2> Objetivos </h2>

<style>
.text-justify {
  text-align: justify;
}
</style>

<span class="text-justify">

- Implementar el algoritmo DBSCAN de forma serial en lenguaje de programación C++, medir su tiempo de ejecución, almacenar los resultados y generar la gráfica/imagen que muestre los puntos que se consideraron outliers.

- Implementar el algoritmo DBSCAN de forma paralela en lenguaje de programación C++ y el estándar OpenMP, haciendo uso de diferentes directivas *#pragma omp* para generar las regiones paralelas. Medir su tiempo de ejecución, almacenar los resultados y generar la gráfica/imagen que muestre los puntos que se consideraron outliers.

- Parametrizar ambas versiones del algoritmo para ejecutar los programas con diferentes valores de entrada para el algoritmo DBSCAN como el número de puntos (20000, 40000, 80000, 120000, 140000, 160000, 180000 o 200000 puntos), el número de iteraciones para promediar los tiempos (que en esta ocasión por la definición del problema queda fijo en 3), y el número de hilos (para la implementación paralela). Todo esto debe poder hacerse de tal manera que sea ejecutable desde un archivo tipo .bat.

- Cada prueba de configuración, dada por el número de puntos e hilos con los que se implementará el algoritmo, debe ser ejecutada 3 veces y se debe calcular el promedio de los tiempos de ejecución.

- Evitar condiciones de carrera al momento de paralelizar, de manera que los resultados obtenidos en la versión paralela y la serial sean los mismos, con la ventaja de que la versión paralela sea más rápida.

- Comparar la eficiencia de la implementación serial y la implementación paralela del algoritmo DBSCAN, mediante la obtención de la gráfica de speedups.

- Realizar un análisis de resultados y determinar las conclusiones correspondientes.

</span>



<h2> Estructura del proyecto </h2>

- .vscode/
    * settings.json
    * tasks.json

- experimento/
    * paralelo/
        * Datos/
            * 20000_data.csv
            * 40000_data.csv
            * 80000_data.csv
            * 120000_data.csv
            * 140000_data.csv
            * 160000_data.csv
            * 180000_data.csv
            * 200000_data.csv
        * Gráficas_puntos/
            * dbScan_20000.jpg
            * dbScan_40000.jpg
            * dbScan_80000.jpg
            * dbScan_120000.jpg
            * dbScan_140000.jpg
            * dbScan_160000.jpg
            * dbScan_180000.jpg
            * dbScan_200000.jpg
        * Resultados/
            * 6_hilos/
                * 20000_results.csv
                * 40000_results.csv
                * 80000_results.csv
                * 120000_results.csv
                * 140000_results.csv
                * 160000_results.csv
                * 180000_results.csv
                * 200000_results.csv
            * 12_hilos/
                * 20000_results.csv
                * 40000_results.csv
                * 80000_results.csv
                * 120000_results.csv
                * 140000_results.csv
                * 160000_results.csv
                * 180000_results.csv
                * 200000_results.csv
            * 24_hilos/
                * 20000_results.csv
                * 40000_results.csv
                * 80000_results.csv
                * 120000_results.csv
                * 140000_results.csv
                * 160000_results.csv
                * 180000_results.csv
                * 200000_results.csv
        * Tiempos_de_ejecucion/
            * 6_hilos/
                * 20000_tiempos.csv
                * 40000_tiempos.csv
                * 80000_tiempos.csv
                * 120000_tiempos.csv
                * 140000_tiempos.csv
                * 160000_tiempos.csv
                * 180000_tiempos.csv
                * 200000_tiempos.csv
            * 12_hilos/
                * 20000_tiempos.csv
                * 40000_tiempos.csv
                * 80000_tiempos.csv
                * 120000_tiempos.csv
                * 140000_tiempos.csv
                * 160000_tiempos.csv
                * 180000_tiempos.csv
                * 200000_tiempos.csv
            * 24_hilos/
                * 20000_tiempos.csv
                * 40000_tiempos.csv
                * 80000_tiempos.csv
                * 120000_tiempos.csv
                * 140000_tiempos.csv
                * 160000_tiempos.csv
                * 180000_tiempos.csv
                * 200000_tiempos.csv
    * serial/
        * Datos/
            * 20000_data.csv
            * 40000_data.csv
            * 80000_data.csv
            * 120000_data.csv
            * 140000_data.csv
            * 160000_data.csv
            * 180000_data.csv
            * 200000_data.csv
        * Gráficas_puntos/
            * dbScan_20000.jpg
            * dbScan_40000.jpg
            * dbScan_80000.jpg
            * dbScan_120000.jpg
            * dbScan_140000.jpg
            * dbScan_160000.jpg
            * dbScan_180000.jpg
            * dbScan_200000.jpg
        * Resultados/
            * 20000_results.csv
            * 40000_results.csv
            * 80000_results.csv
            * 120000_results.csv
            * 140000_results.csv
            * 160000_results.csv
            * 180000_results.csv
            * 200000_results.csv
        * Tiempos_de_ejecucion/
            * 20000_tiempos.csv
            * 40000_tiempos.csv
            * 80000_tiempos.csv
            * 120000_tiempos.csv
            * 140000_tiempos.csv
            * 160000_tiempos.csv
            * 180000_tiempos.csv
            * 200000_tiempos.csv
            
- documento_analisis/
    * Evaluacion_de_desempeño.pdf
- base_dbscan_noise.exe
- dbscan_noise_serial.cpp
- dbscan_noise_serial.exe
- dbscan_noise_paralelo.cpp
- dbscan_noise_paralelo.exe
- pruebas.cpp
- pruebas.exe
- run_dbscan_paralelo.bat
- run_dbscan_serial.bat
- run_experimento_completo.bat
- SpeedUp_dbScan.png
- SpeedUp_dbScan.xlsx
- Evaluacion_de_desempeño.md

<h2> Definición del experimento </h2>

<p style="text-align: justify;">
  El algoritmo DBSCAN funciona como se mencionó en la introducción y, una vez decidido que calcularía la distancia euclidiana y no cualquiera de las otras, entonces ya era posible desarrollar el programa al haberlo entendido. El experimento consiste en la ejecución del algoritmo DBSCAN de forma parametrizada en sus versiones serial y paralela en las diferentes <b>configuraciones</b> solicitadas, las cuales son todas las combinaciones posibles entre <b>número de puntos</b> y <b>número de hilos</b>, de manera que se trabajan 32 configuraciones diferentes, se reportan los tiempos de ejecución de cada uno de ellos, se comparan los resultados de la versión serial con las versiones parametrizadas para cada número de puntos y se genera una gráfica comparativa de <b>rendimientos</b> mediante la métrica <em>speed up</em>. 
</p>

<p style="text-align: justify;">
  El experimento solo se considerará <b>ÉXITOSO</b> en el caso de que la versión paralela sea más rápida que la version serial y que los resultados del obtenidos del algoritmo sean los mismos, lo cual demuestra que se paralelizó correctamente, es decir, sin generar condiciones de carrera. 
</p>

<p style="text-align: justify;">
  Para la implementación del algoritmo DBSCAN en lenguaje de programación C++ se utilizó la biblioteca de OpenMP para la paralelización del algoritmo, ya que ofrece formas sencillas de paralelizar, es compacto y permite utilizar de forma óptima los recursos computacionales, los hilos.
</p>

<p style="text-align: justify;">
  Para lograr obtener toda la información del experimento mencionado, se utilizan diferentes archivos C++, lotes de archivos tipo <em>.bat</em> y los archivos .CSV que contienen los puntos que se generaron con anterioridad para hacer comparables las ejecuciones de los programas. De esta manera, para ejecutar el proceso completo del experimento, se ejecuta el archivo <b>run_experimento_completo.bat</b> que, a su vez, ejecuta el archivo <b>run_dbscan_serial.bat</b> y el archivo <b>run_dbscan_paralelo.bat</b>. 
</p>

<p style="text-align: justify;">
  Se cuenta con archivos .CSV como entrada que llevan el nombre de <em>número_de_puntos</em>_data.csv, donde <em>número_de_puntos</em> toma los valores 20000, 40000, 80000, 120000, 140000, 160000, 180000 y 200000,que a su vez reflejan la cantidad de puntos y las coordenadas (X,Y) que contienen; estos archivos se almacenan en las carpetas <b>Datos/</b>. Estos datos son leídos para ser procesados por el algoritmo DBSCAN en ambas versiones del experimento. 
</p>

<p style="text-align: justify;">
  El archivo <b>run_dbscan_serial.bat</b> ejecuta el archivo ejecutable <b>./dbscan_noise_serial.exe</b> con diferentes parámetros (<b>num_points</b>) para las distintas pruebas del código serial, ejecutando cada configuración en 3 ocasiones, guardando sus tiempos y los promedios de los mismos en los archivos llamados <em>número_de_puntos</em>_tiempos, en donde el número de la primera fila y columna es referente al promedio de las tres mediciones, y los siguientes los tiempos de cada ejecución. Estos archivos se almacenan en la carpeta <b>timepos_de_ejecución/</b>
</p>

<p style="text-align: justify;">
  El archivo <b>run_dbscan_paralelo.bat</b> ejecuta el archivo ejecutable <b>.dbscan_noise_paralelo.exe</b> con diferentes parámetros/argumentos (<b>num_points</b>, <b>num_threads</b>) para las distintas pruebas del código paralelo. Calcula los resultados de forma paralela, para después almacenar los tiempos de ejecución y resultados con la misma logística que en la sección serial, con la diferencia de que en la organización se distinguen los procesos paralelos de 6, 12 y 24 hilos.
</p>

<p style="text-align: justify;">
  Argumentos utilizados:
</p>

<ul>
  <li>El número de puntos se itera entre los siguientes valores: 20000, 40000, 80000, 120000, 140000, 160000, 180000 y 200000.</li>
  <li>El número máximo de hilos se itera entre los siguientes valores: <b>1</b>, <b>6</b> (número de cores virtuales/2), <b>12</b> número de cores virtuales, <b>24</b> (número de cores virtuales*2).</li>
</ul>

<p style="text-align: justify;">
  Finalmente, con los resultados obtenidos se genera la comparación de los tiempos para generar la gráfica de speed ups, así como las gráficas de los resultados de las pruebas de cada configuración, para además comparar los resultados de la versión serial con los de la paralela que, en principio, deben ser iguales, solo que calculados más rápidamente para la versión paralela. La gráfica de los puntos se hace de manera manual con el código otorgado por el profesor, que a su vez sirve para comparar los resultados de el algoritmo propio con el ya previamente comparado el Python. 
</p>


<h2> Explicación detallada de la implementación </h2>

<p style="text-align: justify;">
La implementación del algoritmo DBSCAN en lenguaje de programación C++ se realizó en dos archivos: <strong>./dbscan_noise_serial.cpp</strong> y <strong>./dbscan_noise_paralelo.cpp</strong> de forma similar. La diferencia entre los archivos radica en que <strong>./dbscan_noise_paralelo.cpp</strong> utiliza la biblioteca de OpenMP para la paralelización del algoritmo, algunos de las estructuras de control cíclicas <em>for</em> se paralelizaron con la directiva <strong>#pragma omp parallel for</strong> cuidando de no anidar directivas de paralelismo y aquellas regiones que sabía que podían ocasionar condiciones de carrera con la actualización de alguna variable o punto, se ejecutaron de forma paralela usando la directiva <strong>pragma omp critical</strong>.</p>

<p style="text-align: justify;">
Cabe resaltar que la paralelización se realiza en especial en la función referente al algoritmo, pues el objetivo del experimento como ya se mencionó es monitorear la mejora del algoritmo DBSCAN a medida que se paraleliza con más hilos, y no es tanto el interés en paralelizar la lectura de los datos o la escritura de los resultados. Mencionado lo anterior, los métodos utilizados para la implementación del algoritmo son los siguientes:</p>



<style>
  .list-item {
    margin-bottom: 1em;
    text-align: justify;
  }
</style>

<ul>
  <li class="list-item"><strong>noise_detection</strong>: Ejecuta el algoritmo DBSCAN, ejecutado en dos pasos
    <ol>
      <li>Determina la categoría de cada punto en función de la distancia épsilon y del número mínimo de puntos a distancia épsilon para ser una zona densa.</li>
      <li>Determina si un punto ruido o <em>outlier</em> es épsilon-alcanzable desde un punto core, si es el caso, re-etiquétalo como punto core (de segundo orden).</li>
    </ol>
  Cabe mencionar que la paralelización del programa ocurre principalmente en esta parte, pues es el método que refleja la lógica del algoritmo DBSCAN cuya paralelización interesa experimentar.
  </li>
  <li class="list-item"><strong>load_CSV</strong>: Carga los datos de prueba desde un archivo csv.</li>
  <li class="list-item"><strong>save_to_CSV</strong>: Guarda los resultados del algoritmo en un archivo csv, es decir, la categorización de los puntos como nodos core de primer grado, de segundo grado u <em>outliers</em>.</li>
  <li class="list-item"><strong>save_array_to_CSV</strong>: Guarda los tiempos medidos de los 3 experimentos para las diferentes configuraciones. En cada renglón se almacena el tiempo de cada prueba de cada configuración particular de las variables de entrada. En el primer renglón se almacena el promedio de las 3 pruebas.</li>
  <li class="list-item"><strong>main</strong>: se obtienen los argumentos de entrada del programa, se inicializan los arreglos, se iteran los 3 experimentos, se guardan los resultados, se guardan los tiempos medidos y libera la memoria.</li>
</ul>

<h2> Estrategia de paralelización </h2>

<style>
.text-justify {
  text-align: justify;
}
</style>

<span class="text-justify">

- omp_set_num_threads(num_threads): Se establece el número de hilos a utilizar en la ejecución del programa principal **main**.

- El método **noise_detection** se paraleliza con la directiva **#pragma omp parallel for** en algunos estructuras for explicitas o dentro de otros métodos auxiliares. También se hace uso de la directiva **critical** en aquellas secciones del código que se sabe podrían ocasionar condiciones de carrera.

- Paralelizo haciendo uso, en escencia, de las **directivas critical y parallel for**, para que de esta manera, se asigne
    trabajo equitativo a la cantidad de hilos con la que se cuenta, que en este caso se prueba con el máximo de hilos virtuales,
    que en mi caso son 12, con el doble de ellos (24) y con la mitad (6). A su vez, **critical** se usa donde múltiples hilos 
    pueden intentar acceder y modificar las mismas variables compartidas simultáneamente, evitando así condiciones de carrera. 
    Esto garantiza que las actualizaciones de las variables compartidas se realicen de manera segura.
    
    Si bien la opción de **sections** también resulta viable para resolver el problema, esto implicaría dividir la ejecución del 
    programa en el n número de hilos que se esté utilizando para paralelizar en cada ocasión, lo que implica hacer una división
    de la totalidad del trabajo cada vez en ese mismo número de fors, por lo que abría que agregar un casteo para dicha operación,
    mientras que la asignación de la porción de trabajo en parallel for se asigna de forma autonoma entre ese n número de hilos.
</span>

<h2> Instrucciones de ejecución </h2>

- Para ejecutar el experimento completo, se puede ejecutar el archivo **run_experimento_completo.bat**.

- Para ejecutar únicamente el experimento de la implementación serial, se puede ejecutar el archivo **run_dbscan_serial.bat**.

- Para ejecutar únicamente el experimento de la implementación paralela, se puede ejecutar el archivo **run_dbscan_paralelo.bat**.

- Para ejecutar únicamente el código serial con una sola configuración de variables, se puede ejecutar el siguiente comando desde la terminal en la carpeta de PROYECTO1_DBSCAN: **g++ -o dbscan_noise_serial dbscan_noise_serial.cpp**, seguido de la configuración que se quiera ejecutar de la forma **dbscan_noise_serial** [*Número de puntos*].

- Para ejecutar únicamente el código paralelo con una sola configuración de variables, se puede ejecutar el siguiente comando desde la terminal en la carpeta de PROYECTO1_DBSCAN: **g++ -o dbscan_noise_paralelo dbscan_noise_paralelo.cpp -fopenmp**, seguido de la configuración que se quiera ejecutar de la forma **dbscan_noise_serial** [*Número de puntos*] [*Número de hilos*].

- Podrá encontrar los resultados de la ejecución en las carpetas como se indicó en la sección de estructura del proyecto.


<h2> Interpretación, análisis de resultados y comparación de versión serial vs versión paralela</h2>

<p> En resúmen, puede considerarse que el experimento demuestra exitosamente las ventajas de paralelizar un algoritmo, en este caso DBSCAN. Si bien no es totalmente paralelizable dado que existe dependencia de un paso del algoritmo para ejecutar el siguiente, la mejoría se hace presente en todos los casos experimentados. 
</p>

<h3> Resultados versión serial vs versión paralela </h3>

Mediante la comparación de las gráficas de los puntos core de primer y segundo grado, así como de los puntos ruido para ambas versiones del experimento, es posible percatarse de que la paralelización fue exitosa en cuanto a ejecución, es decir, no hay errores derivados de condiciones de carrera, entre otras cosas. Para comprobarlo, se muestran las gráficas para cada n número de puntos en la versión final y paralela, lado a lado.

![20000 puntos](documento_analisis/Comparativa20000.jpg "Title")

![40000 puntos](documento_analisis/Comparativa40000.jpg "Title")

![80000 puntos](documento_analisis/Comparativa80000.jpg "Title")

![120000 puntos](documento_analisis/Comparativa120000.jpg "Title")

![140000 puntos](documento_analisis/Comparativa140000.jpg "Title")

![160000 puntos](documento_analisis/Comparativa160000.jpg "Title")

![180000 puntos](documento_analisis/Comparativa180000.jpg "Title")

![200000 puntos](documento_analisis/Comparativa200000.jpg "Title")

Una vez que nos aseguramos de que los resultados son correctos e iguales para ambas versiones, es necesario comparar el desarrollo del algoritmo DBSCAN, pero ahora en términos de ejecución y el tiempo que conlleva realizar cada experimento para cada versión. La mejor manera para visualizar esta comparativa es mediante una gráfica de speed ups.

<h3> Gráfica de Speed up </h3>

![Speed up](speedUp_dbScan.png "Title")

Como puede verse en la gráfica anterior, la velocidad de ejecución de los programas siempre mejora a medida que aumenta el número de hilos, siendo el uso de un único hilo la versión serial y el resto los experimentos paralelos. 

Si bien pudiera pensarse en primera instancia que la relación de mejoría del speed up debería ser proporcional al incremento de hilos utilizados para la paralelización, esto no sucede. Puede deberse a que el algoritmo DBSCAN no puede ser totalmente paralelizable, ya que, por ejemplo. El segundo paso (asignar puntos core de segundo grado) depende para ser iniciado que el primer paso haya terminado, de manera que se genera, en ocasiones, que el overhead de la paralelización por la comunicación entre los hilos y la sincronización de los mismos, puede ser mayor que el beneficio de la paralelización.

En cualquier caso, es apreciable que para todos las configuraciones experimentadas hay una mejoría de la versión paralela contra la serial, y entre los experimentos paralelos, también mejoran los tiempos de ejecución al utilizar más hilos (aunque esta mejora no sea proporcional).

<h2> Descripción del equipo donde se ejecutaron las pruebas</h2>

<h3> Hardware </h3>

- Computadora: HP EliteBook 640 14 inch G9 Notebook PC
- Procesador: Intel64 Family 6 Model 154 Stepping 4 GenuineIntel
- Memoria RAM: 16 GB
- Disco duro: KIOXA 300 GB 
- Cores físicos: 6
- Cores lógicos: 12
- Velocidad del procesador: 1.8 GHz
- Velocidad de la memoria RAM: 3200 MHz

<h3> Software </h3>

- Sistema Operativo: Microsoft Windows 10 Enterprise
- IDE: Visual Studio Code
- Lenguajes de programación: C++, Python
- Biblioteca de paralelización: OpenMP
- Compilador: g++ (Rev6, Built by MSYS2 project) 13.1.0
- Versión de C++: C++17
- Versión de Python: 3.8.5

<h2> Conclusiones </h2>

<p> El experimento resultó ser un éxito. La paralelización de un programa dificilmente resulta ser total, por lo que siempre se está propenso a condiciones de carrera (hay que evitarlas en la medida de lo posible), overhead de sincronización y comunicación entre procesos, entre otras cosas.

Sin embargo, el experimento demuestra que aunque la relación del incremento de hilos para la paralelización del programa no es proporcional, vale la pena hacer el ejercicio, por que siempre se presentará una mejora que, en grandes producciones, sería importante aprovechar. </p>

<h2> Referencias </h2>

- [OpenMP](https://www.openmp.org/)

- [C++](https://docs.python.org/3/howto/regex.html)

- [G++](https://www.geeksforgeeks.org/compiling-with-g-plus-plus/)

- [Python](https://www.python.org/)




