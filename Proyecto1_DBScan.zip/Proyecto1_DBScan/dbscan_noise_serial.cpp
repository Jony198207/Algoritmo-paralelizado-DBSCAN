/**
 * @file dbscan_noise_serial.cpp
 * @date 2023-10-14
 * @author Jonathan de Jesús Gutiérrez Diaz
 * @brief Código serial del algoritmo dbScan que lee los datos de un archivo .csv, detecta el ruido y escribe los resultados en un archivo .csv
 * @param size Número de puntos a evaluar
 * @param output_file_path Ruta para crear el archivo de resultados
 * @param input_file_path Ruta del archivo de entrada
 * */


#include <omp.h>
#include <iostream>
#include <string>
#include <fstream>
#include <cmath>
#include <time.h>
#include <sys/stat.h>
#include <sys/types.h>

using namespace std;



/**
 * @name noise_detection
 * @brief Función que detecta los puntos "ruido" de los datos leidos del .csv
 * @param points Arreglo de puntos - Arreglo de arreglos de floats [[X, Y, ruido], [X, Y, ruido], ...]
 * @param epsilon Distancia maxima para considerar que un punto está en un cluster
 * @param min_samples Número mínimo de puntos a menos de epsilon distancia para considerarse nodo core
 * @param size Tamaño del arreglo (cantidad de puntos)
 * @return Matriz de puntos con su respectiva clasificación de puntos  
 * */

void noise_detection(float** points, float epsilon, int min_samples, long long int size) {
    cout << "Step 1" << "\n"; 

    /* Paso 1: Determina la categoría 
    de cada punto en función de la 
    distancia épsilon y del número 
    mínimo de puntos a distancia 
    épsilon para ser una zona densa.*/
    for (long long int i=0; i < size; i++) {
        long long int samples = 0;
        long long int recorrido = 0;
        while (samples < min_samples && recorrido < size)
        {
            if(sqrt(float(pow((points[i][0] - points[recorrido][0]),2) + pow((points[i][1] - points[recorrido][1]),2))) <= epsilon){
                samples++;
            }
            recorrido++;
        }
        if (samples == min_samples){
            points[i][2] = 1; //definido como punto de interes
        }else{
            points[i][2] = 0; //definido como ruido
        }
    }      

    cout << "Step 2" << "\n"; 
    /* Paso 2: Determina si un 
    punto ruido o outlier es 
    épsilon-alcanzable desde 
    un punto core, si es el 
    caso, re-etiquétalo como 
    punto core (de segundo 
    orden) */

    for (long long int j=0; j < size; j++) {
        if (points[j][2] == 0){ // actualmente es considerado un punto ruido
            long long int recorrido = 0;
            bool cambio = false;
            while(cambio == false && recorrido < size){
                if((sqrt(float(pow((points[j][0] - points[recorrido][0]),2) + pow((points[j][1] - points[recorrido][1]),2))) <= epsilon) && (points[recorrido][2] == 1)){
                    cambio = true;
                    points[j][2] = 2; // asignamos otro color para que no tome estos nuevos puntos como cores de primer orden.
                }
                recorrido++;
            }
        }  
    }      

    for(long long int k=0; k < size; k++){
        if(points[k][2] == 2){
            points[k][2] = 1;
        }
    }

    cout << "Complete" << "\n"; 
}


/**
 * @name load_CSV
 * @brief Función para leer un archivo CSV y guardar los puntos en una matriz llamada puntos
 * @param file_name Nombre del archivo CSV
 * @param points Matriz donde se guardarán los puntos
 * @param num_points Cantidad de puntos que se leerán del archivo
 * */

void load_CSV(string file_name, float** points, long long int size) {
    ifstream in(file_name);
    if (!in) {
        cerr << "Couldn't read file: " << file_name << "\n";
    }
    long long int point_number = 0; 
    while (!in.eof() && (point_number < size)) {
        char* line = new char[12];
        streamsize row_size = 12;
        in.read(line, row_size);
        string row = line;
        //cout << stof(row.substr(0, 5)) << " - " << stof(row.substr(6, 5)) << "\n";
        points[point_number][0] = stof(row.substr(0, 5));
        points[point_number][1] = stof(row.substr(6, 5));
        point_number++;
    }
}


/**
 * @name save_to_CSV
 * @brief Función para guardar los puntos con su respectiva clasificación de ruido 
 * @param file_name Nombre del archivo CSV
 * @param points Matriz donde se guardarán los puntos
 * @param size Cantidad de puntos que se leerán del archivo
 * */

void save_to_CSV(string file_name, float** points, long long int size) {
    fstream fout;
    fout.open(file_name, ios::out);
    for (long long int i = 0; i < size; i++) {
        fout << points[i][0] << ","
             << points[i][1] << ","
             << points[i][2] << "\n";
    }
}

/**
 * @name save_array_to_CSV
 * @brief Función para guardar los tiempos de ejecución (3 veces por configuración) en un archivo de excelm .csv
 * En la primera fila (renglón) se almacena el promedio del tiempo de ejecución de las 3 iteraciones con esa configuración  
 * @param file_name Nombre del archivo CSV donde se guardaran los datos
 * @param times arreglo que contiene los 3 tiempos de ejecución
 * @param size Tamaño del arreglo
 * */

void save_array_to_CSV(string file_name, float* times,  int size) {
    fstream fout;
    fout.open(file_name, ios::out);
    for (int i = 0; i < size; i++) {
        fout << times[i] << "\n";
    }
}


/**
 * @name main
 * @brief Función main del programa, en esta ocasión todas las configuraciones suceden con 1 solo thread (Serial). 
 * @param argc Cantidad de argumentos de entrada 
 * @param argv Argumentos de entrada [nombre del programa, numero de puntos]
 * @return 0 si el programa termina correctamente
 * */

int main(int argc, char** argv) {

    // Se definen las variables del problema
    const float epsilon = 0.03;
    const int min_samples = 10;
    long long int size; // = 4000; 
    const int iteraciones_por_configuracion = 3;


    // PARAMETRIZACIÓN DEL PROGRAMA
    // De esta manera, podemos ejecutar un .bat, de nombre run_dbscan_serial.bat, y ejecutar todas las configuraciones
    // solicitadas de una sola vez. 

    try{
            // Si no se pasan argumentos, se usan los valores por defecto
            if(argc == 1){
                size = 4000;
            }else
                // Si se pasan argumentos, se usan esos valores
                if(argc == 2){
                    size = (long long int) stoi(argv[1]);
                    if (size < 1) 
                        throw std::invalid_argument("Invalid number of points");
                }else
                    // Si se pasan más o menos argumentos, se lanza una excepción
                    throw std::invalid_argument("Invalid number of arguments");
        } catch (const std::exception& e) {
            // Se imprime el mensaje de error y se muestra la forma correcta de ejecutar el programa
            cout << e.what() << "\n";
            cout << "Uso: ./dbscan_noise_serial.cpp <numero_de_puntos>" << "\n";
            return 1;
        }
     
    float** points = new float*[size];

    for(long long int i = 0; i < size; i++) {
        points[i] = new float[3]{0.0, 0.0, 0.0}; 
        // index 0: position x
        // index 1: position y 
        // index 2: 0 for noise point, 1 for core point
    }

    // Lee los puntos del archivo csv  y se guardan en la matriz de puntos
    string input_file_name = "experimento/serial/Datos/" + to_string(size)+"_data.csv";
    try{
        load_CSV(input_file_name, points, size);
    } catch (const std::exception& e) {
        cout << "Error: load_CSV()" << "\n";
        cout << e.what() << "\n";
    }


    string output_file_name;
    float* times = new float[4]{0.0}; // Arreglo para guardar los tiempos de ejecución de cada experimento
    float sum_times = 0.0; // Variable para guardar la suma de los tiempos de ejecución de los 10 experimentos
    float avg_time = 0.0; // Variable para guardar el promedio de los tiempos de ejecución de los 10 experimentos
    
    // Se itera 3 veces para repetir el experimento con esta configuración de parámetros
    
    for(int i = 1; i < 4; i++){

        // Invoca el método de noise_detections con la matriz de puntos, min_samples y el número total de puntos
        try{
            const clock_t begin_time = clock();
            noise_detection(points, epsilon, min_samples, size);  
            times[i] = float( clock () - begin_time ) /  CLOCKS_PER_SEC; // Esto nos da el tiempo en segundos
            sum_times += times[i];
        } catch (const std::exception& e) {
            cout << "Error: noise_detection()" << "\n";
            cout << e.what() << "\n";
        }
            
        // Guarda el resultado de los puntos con su respectivo senalamiento de puntos ruido en el archivo de salida
        output_file_name = "experimento/serial/Resultados/" + to_string(size)+"_results.csv";
        try{
            save_to_CSV(output_file_name, points, size);
        } catch (const std::exception& e) {
            cout << "Error: save_to_CSV()" << "\n";
            cout << e.what() << "\n";
        }
    }

    // Guarda los tiempos de ejecución de los 3 experimentos y el promedio en la primera fila en un archivo csv 
    avg_time = sum_times / 3.0;
    times[0] = avg_time;
    output_file_name = "experimento/serial/Tiempos_de_ejecucion/" + to_string(size)+"_tiempos.csv";
    try{
        save_array_to_CSV(output_file_name, times, 4);
    } catch (const std::exception& e) {
        cout << "Error: save_array_to_CSV()" << "\n";
        cout << e.what() << "\n";
    }


    // Libera la memoria al borrar la matriz de puntos
    for(long long int i = 0; i < size; i++) {
        delete[] points[i];
    }

    delete[] points;

    return 0;
}










 